require "chefspec"

describe "s3cmd::default" do

  def create_chef_run
    c = ChefSpec::ChefRunner.new do |node|
      node['memory'] = { 'total' => "4096" }
    end
    Chef::EncryptedDataBagItem.should_receive(:load_secret).
      with('/root/secret').at_least(1).times.and_return('xx')
    Chef::EncryptedDataBagItem.should_receive(:load).
      with('aws-_default', 's3', 'xx').at_least(1).times.
      and_return({ 's3id'=>'fakes3id', 's3key'=>'fakes3key' })
    c.converge 's3cmd::default'
  end

  it "should add s3cmd repo file" do
    chef_run = create_chef_run
    chef_run.should create_file '/etc/yum.repos.d/s3tools.repo'
    chef_run.template('/etc/yum.repos.d/s3tools.repo').mode.should == '644'
  end

  it "should install package s3cmd" do
    chef_run = create_chef_run
    chef_run.should install_package 's3cmd'
  end

  it "should add s3cmd config template for user ec2-user" do
    chef_run = create_chef_run
    chef_run.should create_file '/home/ec2-user/.s3cfg'
    chef_run.template('/home/ec2-user/.s3cfg').mode.should == '400'
    chef_run.template('/home/ec2-user/.s3cfg').
      should be_owned_by('ec2-user', 'ec2-user')
    chef_run.template('/home/ec2-user/.s3cfg').variables.should ==
      { :s3_key_id=>'fakes3id', :s3_key_secret=>'fakes3key' }
  end

end
