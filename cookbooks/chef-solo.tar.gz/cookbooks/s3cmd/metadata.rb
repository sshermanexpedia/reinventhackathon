description "Deploys s3cmd tool"
version "1.0.0"
recipe "s3cmd", "Installs and configures s3 authentication tool"
