yum_package "postgresql-server" do
    action :install
end
