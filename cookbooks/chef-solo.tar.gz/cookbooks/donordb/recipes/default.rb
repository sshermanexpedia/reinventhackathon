yum_package "postgres"
    action :install
end
