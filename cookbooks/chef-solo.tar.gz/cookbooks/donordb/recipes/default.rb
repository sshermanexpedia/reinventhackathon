yum_package "postgresql93-server" do
    action :install
end
