CREATE USER donoruser;
CREATE DATABASE donorschoose;