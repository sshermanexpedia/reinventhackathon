version "0.0.1"
depends s3cmd
